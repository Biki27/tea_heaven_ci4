<?php
$extra_css = '
body { padding-top:90px; background:#f9fafb; font-family:-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
:root { --leaf-green:#6B8E23; --warm-brown:#4E342E; --tea-gold:#D4AF37; }

.checkout-wrap { max-width:1152px; margin:0 auto; padding:2rem 1rem; }
.page-title { font-size:1.6rem; font-weight:700; margin-bottom:1.5rem; color:#111; }
.progress-bar-wrap { margin-bottom:2rem; }
.progress-labels { display:flex; justify-content:space-between; font-size:0.875rem; color:#6b7280; margin-bottom:0.5rem; }
.progress-label.done { color:var(--leaf-green); font-weight:600; }
.progress-track { width:100%; height:8px; background:#e5e7eb; border-radius:9999px; }
.progress-fill { height:8px; background:linear-gradient(to right,var(--leaf-green),#90C695); border-radius:9999px; width:100%; }

.checkout-grid { display:grid; gap:2rem; grid-template-columns:1fr; }
@media(min-width:1024px) { .checkout-grid { grid-template-columns:1fr 1fr; } }

.card-section { background:white; border-radius:16px; padding:1.8rem; box-shadow:0 4px 15px rgba(0,0,0,0.06); margin-bottom:1.5rem; }
.card-section h2 { font-size:1.15rem; font-weight:700; margin-bottom:1.2rem; color:#111; padding-bottom:0.8rem; border-bottom:2px solid #f0f0f0; display:flex; align-items:center; gap:8px; }
.card-section h2 i { color:var(--leaf-green); }

.form-row { display:grid; gap:1rem; margin-bottom:1rem; }
.form-row.col-2 { grid-template-columns:1fr 1fr; }
@media(max-width:600px){ .form-row.col-2{ grid-template-columns:1fr; } }
.form-group { display:flex; flex-direction:column; gap:0.3rem; }
.form-group label { font-size:0.85rem; font-weight:600; color:#374151; }
.form-group input, .form-group select, .form-group textarea { padding:10px 14px; border:1.5px solid #d1d5db; border-radius:8px; font-size:0.95rem; transition:all 0.2s; width:100%; font-family:inherit; }
.form-group input:focus, .form-group select:focus, .form-group textarea:focus { outline:none; border-color:var(--leaf-green); box-shadow:0 0 0 3px rgba(107,142,35,0.15); }
.form-group textarea { resize:vertical; min-height:80px; }

/* Payment method selector */
.payment-methods { display:flex; flex-direction:column; gap:10px; }
.pay-option { display:flex; align-items:center; gap:12px; padding:14px 16px; border:2px solid #e5e7eb; border-radius:10px; cursor:pointer; transition:all 0.2s; }
.pay-option:hover { border-color:var(--leaf-green); background:#f0f7e6; }
.pay-option input[type="radio"] { accent-color:var(--leaf-green); width:18px; height:18px; }
.pay-option.selected { border-color:var(--leaf-green); background:#f0f7e6; }
.pay-option .pay-icon { font-size:1.4rem; }
.pay-option .pay-label { font-weight:600; font-size:14px; }
.pay-option .pay-sub   { font-size:12px; color:#6b7280; }

/* Order Summary */
.order-summary { background:white; border-radius:16px; padding:1.8rem; box-shadow:0 4px 15px rgba(0,0,0,0.06); position:sticky; top:100px; }
.order-summary h2 { font-size:1.1rem; font-weight:700; margin-bottom:1.2rem; border-bottom:2px solid #f0f0f0; padding-bottom:0.8rem; }
.order-item { display:flex; align-items:center; gap:12px; padding:12px 0; border-bottom:1px solid #f0f0f0; }
.order-item:last-of-type { border-bottom:none; }
.order-item img { width:56px; height:56px; border-radius:8px; object-fit:cover; }
.order-item-info { flex:1; }
.order-item-info .name { font-size:14px; font-weight:600; color:#222; margin-bottom:2px; }
.order-item-info .qty  { font-size:12px; color:#999; }
.order-item-price { font-weight:700; color:var(--leaf-green); font-size:14px; }

.summary-rows { margin-top:1rem; }
.summary-row { display:flex; justify-content:space-between; padding:8px 0; font-size:14px; color:#555; border-bottom:1px solid #f9f9f9; }
.summary-row.total { font-size:1.2rem; font-weight:800; color:var(--leaf-green); border-top:2px solid var(--leaf-green); border-bottom:none; padding-top:12px; margin-top:4px; }

.pay-btn { width:100%; padding:16px; background:linear-gradient(135deg,var(--leaf-green),#90C695); border:none; border-radius:50px; color:white; font-size:1.1rem; font-weight:700; cursor:pointer; transition:all 0.3s; box-shadow:0 8px 25px rgba(107,142,35,0.35); margin-top:1.5rem; letter-spacing:0.5px; }
.pay-btn:hover { transform:translateY(-2px); box-shadow:0 15px 35px rgba(107,142,35,0.5); }
.pay-btn:disabled { opacity:0.7; cursor:not-allowed; transform:none; }
.security-note { text-align:center; margin-top:12px; font-size:12px; color:#999; display:flex; align-items:center; justify-content:center; gap:5px; }
';
echo view('layouts/header', compact('extra_css') + ['title' => 'Checkout — Tea Haven', 'cartCount' => $cartCount ?? 0]);

// Split full name if present
$firstName = $user['first_name'] ?? '';
$lastName  = $user['last_name'] ?? '';
if (empty($firstName) && empty($lastName) && !empty($user['name'])) {
    $parts = explode(' ', $user['name'], 2);
    $firstName = $parts[0];
    $lastName  = $parts[1] ?? '';
}
?>

<div class="checkout-wrap">
    <h1 class="page-title"><i class="fas fa-lock me-2" style="color:var(--leaf-green);"></i>Secure Checkout</h1>

    <div class="progress-bar-wrap">
        <div class="progress-labels">
            <span class="progress-label done"><i class="fas fa-check-circle"></i> Cart</span>
            <span class="progress-label done">Details</span>
            <span class="progress-label" style="color:var(--leaf-green); font-weight:700;">Payment</span>
        </div>
        <div class="progress-track"><div class="progress-fill"></div></div>
    </div>

    <form id="checkout-form" class="checkout-grid" method="POST" action="<?= base_url('order/place') ?>">
        <?= csrf_field() ?>
        
        <div>
            <div class="card-section">
                <h2><i class="fas fa-map-marker-alt"></i> Shipping Address</h2>
                <div class="form-row col-2">
                    <div class="form-group">
                        <label>First Name *</label>
                        <input type="text" name="first_name" id="first_name" value="<?= esc($firstName) ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Last Name *</label>
                        <input type="text" name="last_name" id="last_name" value="<?= esc($lastName) ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Email *</label>
                        <input type="email" name="email" id="email" value="<?= esc($user['email'] ?? session()->get('user_email')) ?>" required>
                    </div>
                </div>
                <div class="form-row col-2">
                    <div class="form-group">
                        <label>Phone *</label>
                        <input type="tel" name="phone" id="phone" value="<?= esc($user['phone'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Pincode *</label>
                        <input type="text" name="pincode" id="pincode" maxlength="6" placeholder="e.g. 700001" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Address *</label>
                        <input type="text" name="address" id="address" placeholder="House/Flat No, Street" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Landmark (optional)</label>
                        <input type="text" name="notes" placeholder="Near...">
                    </div>
                </div>
                <div class="form-row col-2">
                    <div class="form-group">
                        <label>City *</label>
                        <input type="text" name="city" id="city" required>
                    </div>
                    <div class="form-group">
                        <label>State *</label>
                        <select name="state" id="state" required>
                            <option value="">Select State</option>
                            <?php foreach (['Andhra Pradesh','Assam','Bihar','Goa','Gujarat','Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh','Uttarakhand','West Bengal','Delhi'] as $st): ?>
                                <option><?= $st ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="card-section">
                <h2><i class="fas fa-credit-card"></i> Payment Method</h2>
                <div class="payment-methods">
                    <label class="pay-option selected" id="pay-razorpay">
                        <input type="radio" name="payment_method" value="razorpay" checked>
                        <span class="pay-icon">💳</span>
                        <div>
                            <div class="pay-label">UPI / Cards / Net Banking</div>
                            <div class="pay-sub">Powered by Razorpay — 100% Secure</div>
                        </div>
                    </label>
                    <label class="pay-option" id="pay-cod">
                        <input type="radio" name="payment_method" value="cod">
                        <span class="pay-icon">💵</span>
                        <div>
                            <div class="pay-label">Cash on Delivery</div>
                            <div class="pay-sub">Pay when you receive your order</div>
                        </div>
                    </label>
                </div>
            </div>
        </div>

        <div>
            <div class="order-summary">
                <h2><i class="fas fa-receipt" style="color:var(--leaf-green);"></i> Order Summary</h2>

                <?php foreach ($items ?? [] as $item): ?>
                    <?php 
                        $imgSrc = str_starts_with($item['image'], 'http') ? $item['image'] : base_url('images/products/' . $item['image']); 
                        $displayPrice = $item['sale_price'] > 0 ? $item['sale_price'] : $item['price'];
                    ?>
                    <div class="order-item">
                        <img src="<?= $imgSrc ?>" alt="<?= esc($item['name']) ?>">
                        <div class="order-item-info">
                            <div class="name"><?= esc($item['name']) ?></div>
                            <div class="qty">Qty: <?= $item['quantity'] ?></div>
                        </div>
                        <div class="order-item-price">₹<?= number_format($displayPrice * $item['quantity']) ?></div>
                    </div>
                <?php endforeach; ?>

                <div class="summary-rows">
                    <div class="summary-row">
                        <span>Subtotal</span>
                        <span>₹<?= number_format($subtotal ?? 0) ?></span>
                    </div>
                    <?php if (($discount ?? 0) > 0): ?>
                        <div class="summary-row" style="color:#27ae60;">
                            <span>Discount</span>
                            <span>−₹<?= number_format($discount) ?></span>
                        </div>
                    <?php endif; ?>
                    <div class="summary-row">
                        <span>Tax (GST 5%)</span>
                        <span>₹<?= number_format($tax ?? 0) ?></span>
                    </div>
                    <div class="summary-row">
                        <span>Shipping</span>
                        <span><?= ($shipping ?? 0) > 0 ? '₹' . number_format($shipping) : '<span style="color:#27ae60;">FREE</span>' ?></span>
                    </div>
                    <div class="summary-row total">
                        <span>Total</span>
                        <span>₹<?= number_format($total ?? 0) ?></span>
                    </div>
                </div>

                <button type="submit" class="pay-btn" id="pay-btn">
                    <i class="fas fa-lock me-2"></i>
                    <span id="payBtnText">Pay ₹<?= number_format($total ?? 0) ?></span>
                </button>
                <div class="security-note">
                    <i class="fas fa-shield-alt"></i> Secured by 256-bit SSL encryption
                </div>
            </div>
        </div>
    </form>
</div>

<?php
$footer_scripts = '
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script src="' . base_url('js/payment.js') . '"></script>
<script>
// Expose config to the payment.js file
CheckoutConfig.razorpayKeyId = "' . esc($razorpay_key ?? '') . '";

// Handle form submission routing
const form = document.getElementById("checkout-form");
const payBtn = document.getElementById("pay-btn");
const codRadio = document.querySelector("input[value=\'cod\']");
const rzpRadio = document.querySelector("input[value=\'razorpay\']");

// Payment method highlight toggle
document.querySelectorAll(".pay-option").forEach(el => {
    el.addEventListener("click", () => {
        document.querySelectorAll(".pay-option").forEach(e => e.classList.remove("selected"));
        el.classList.add("selected");
        
        // Change button text dynamically
        if(codRadio.checked) {
            document.getElementById("payBtnText").innerText = "Place Order (COD)";
        } else {
            document.getElementById("payBtnText").innerText = "Pay ₹' . number_format($total ?? 0) . '";
        }
    });
});

// Intercept form submit
form.addEventListener("submit", (e) => {
    // If Razorpay is selected, stop the standard form submission and trigger AJAX
    if(rzpRadio.checked) {
        e.preventDefault();
        
        // Basic HTML5 validation check
        if(!form.checkValidity()) {
            form.reportValidity();
            return;
        }
        
        CheckoutConfig.processPayment();
    }
    // If COD is selected, allow the standard POST to /order/place to continue natively
});
</script>
';
echo view('layouts/footer', compact('footer_scripts'));
?>