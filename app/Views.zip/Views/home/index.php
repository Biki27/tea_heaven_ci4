<?php
$extra_css = '
body {
    background: linear-gradient(rgba(0,0,0,0.7),rgba(0,0,0,0.7)), url("' . base_url('images/background.png') . '") no-repeat center center;
    background-size: cover;
    background-attachment: fixed;
    color: #fff;
    padding-top: 80px;
}

/* HERO SLIDER */
.slide-banner { position:relative; height:85vh; min-height:600px; overflow:hidden; display:flex; align-items:center; justify-content:center; }
.bg-video { position:absolute; top:50%; left:50%; width:100%; height:100%; object-fit:cover; transform:translate(-50%,-50%); z-index:-2; }
.slide-banner::after { content:""; position:absolute; inset:0; background:linear-gradient(rgba(0,0,0,0.6),rgba(0,0,0,0.75)); z-index:-1; }
.slide { position:absolute; width:100%; opacity:0; transition:opacity 1s ease; display:flex; justify-content:center; pointer-events:none; }
.slide.active { opacity:1; pointer-events:all; }
.slide-content { text-align:center; max-width:750px; padding:50px; background:rgba(255,255,255,0.08); backdrop-filter:blur(15px); border-radius:20px; box-shadow:0 25px 60px rgba(0,0,0,0.4); }
.slide-title { font-size:clamp(2.2rem,5vw,3.5rem); font-weight:700; margin-bottom:20px; }
.slide-subtitle { font-size:1.2rem; margin-bottom:30px; }
.slide-btn { background:linear-gradient(135deg,#6B8E23,#90C695); padding:14px 40px; border-radius:50px; color:#fff; font-weight:600; text-decoration:none; transition:0.3s; box-shadow:0 10px 30px rgba(107,142,35,0.4); display:inline-block; }
.slide-btn:hover { transform:translateY(-3px); box-shadow:0 18px 40px rgba(107,142,35,0.6); color:#fff; }
.slide-dots { position:absolute; bottom:40px; left:50%; transform:translateX(-50%); display:flex; gap:12px; z-index:10; }
.dot { width:12px; height:12px; border-radius:50%; background:rgba(255,255,255,0.5); cursor:pointer; transition:0.3s; border:none; }
.dot.active { background:#6B8E23; transform:scale(1.3); }

/* NEW ARRIVALS GRID */
.best-seller { padding:80px 5%; text-align:center; background-color:rgb(216,214,211); }
.section-title { font-size:42px; font-weight:500; margin-bottom:60px; }
.product-container { display:grid; grid-template-columns:repeat(4,1fr); gap:40px; }
.product-card { position:relative; background:#f0f0f0; padding:40px 20px; transition:0.3s; cursor:pointer; }
.product-card:hover { background:#eaeaea; }
.image-box { width:220px; height:220px; margin:0 auto 25px; border-radius:50%; overflow:hidden; background:#ddd; display:flex; align-items:center; justify-content:center; }
.image-box img { width:100%; height:100%; object-fit:cover; }
.product-card h3 { font-size:18px; font-weight:500; margin-bottom:10px; color:black; }
.price .new { color:#7a9c59; margin-right:10px; }
.price .old { text-decoration:line-through; color:#999; }
.sale-badge { position:absolute; top:2px; right:0px; background:#e53935; color:white; padding:4px 25px; font-size:14px; border-radius:50%; }
.add-to-cart-btn { margin-top:12px; background:#6B8E23; color:white; border:none; padding:8px 22px; border-radius:20px; font-size:13px; font-weight:600; cursor:pointer; transition:0.3s; }
.add-to-cart-btn:hover { background:#4E342E; }

/* BEST SELLER */
.best-seller-section { padding:100px 0; background:rgba(0,0,0,0.25); backdrop-filter:blur(8px); }
.best-seller-section .section-title { color:#bdbbbb; letter-spacing:1px; }
.best-seller-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:30px; }
.bs-card { background:#fff; border-radius:16px; padding:20px; text-align:center; transition:0.4s; color:#333; box-shadow:0 8px 25px rgba(0,0,0,0.08); }
.bs-card:hover { transform:translateY(-10px); box-shadow:0 20px 40px rgba(0,0,0,0.15); }
.bs-image { width:100%; height:240px; overflow:hidden; border-radius:12px; margin-bottom:15px; position:relative; }
.bs-image img { width:100%; height:100%; object-fit:cover; transition:0.5s; }
.bs-card:hover img { transform:scale(1.1); }
.bs-hover { position:absolute; inset:0; background:rgba(0,0,0,0.4); display:flex; justify-content:center; align-items:center; opacity:0; transition:0.3s; }
.bs-card:hover .bs-hover { opacity:1; }
.add-cart { background:#fff; border:none; padding:10px 25px; border-radius:50px; font-weight:600; transition:0.3s; cursor:pointer; }
.add-cart:hover { background:var(--leaf-green); color:#fff; }
.bs-price .new { color:var(--leaf-green); font-weight:600; }
.bs-price .old { text-decoration:line-through; color:#999; margin-left:8px; }

/* ABOUT */
.about-section { padding:90px 0; background:#ffffff; color:#333; }
.about-wrapper { display:flex; align-items:center; justify-content:space-between; gap:50px; }
.about-left, .about-right { flex:1; }
.about-content h2 { font-size:34px; font-weight:700; margin-bottom:15px; color:#222; }
.about-content p { font-size:16px; line-height:1.6; color:#555; margin-bottom:15px; }
.about-btn { display:inline-block; padding:12px 30px; background:#6B8E23; color:#fff; border-radius:50px; text-decoration:none; font-weight:600; transition:0.3s; }
.about-btn:hover { background:#D4AF37; color:#000; }
.about-image { overflow:hidden; border-radius:10px; }
.about-image img { width:100%; max-height:320px; object-fit:cover; border-radius:12px; transition:0.5s ease; }
.about-image:hover img { transform:scale(1.08); }

/* CATEGORY */
.tea-category-section { padding:90px 5%; background:transparent; }
.tea-container { display:grid; grid-template-columns:repeat(4,1fr); gap:25px; }
.tea-card { position:relative; overflow:hidden; border-radius:6px; cursor:pointer; }
.tea-card img { width:100%; height:320px; object-fit:cover; transition:0.6s ease; }
.tea-card:hover img { transform:scale(1.08); }
.tea-overlay { position:absolute; top:50%; left:50%; transform:translate(-50%,-50%) scale(0.8); background:rgba(238,237,237,0.85); backdrop-filter:blur(10px); padding:30px 40px; text-align:center; border-radius:4px; opacity:0; transition:0.4s ease; }
.tea-card:hover .tea-overlay { opacity:1; transform:translate(-50%,-50%) scale(1); }
.tea-overlay h3 { font-size:22px; margin-bottom:10px; font-weight:600; color:black; }
.tea-overlay a { text-decoration:none; font-size:12px; letter-spacing:2px; font-weight:600; border-bottom:1px solid #000; padding-bottom:3px; color:#000; }

@media(max-width:1200px) { .best-seller-grid,.product-container { grid-template-columns:repeat(3,1fr); } }
@media(max-width:992px) { .best-seller-grid,.product-container,.tea-container { grid-template-columns:repeat(2,1fr); } .about-wrapper { flex-direction:column; text-align:center; } }
@media(max-width:576px) { .best-seller-grid,.product-container,.tea-container { grid-template-columns:1fr; } .section-title { font-size:30px; } }
';
echo view('layouts/header', compact('extra_css') + ['title' => 'Tea Haven - Premium Teas', 'cartCount' => $cartCount ?? 0]);
?>

<!-- HERO -->
<section class="slide-banner">
    <video autoplay muted loop playsinline class="bg-video">
        <source src="<?= base_url('videos/tea.mp4') ?>" type="video/mp4">
    </video>

    <?php
    $slides = [
        ['title' => 'Premium Black Tea',    'sub' => 'Rich, bold flavors from finest Darjeeling estates',  'cat' => 'black-tea'],
        ['title' => 'Organic Green Tea',    'sub' => 'Fresh antioxidant-rich leaves hand-picked daily',     'cat' => 'green-tea'],
        ['title' => 'Herbal Infusions',     'sub' => 'Caffeine-free wellness blends for mind and body',     'cat' => 'herbal'],
    ];
    foreach ($slides as $i => $s):
    ?>
        <div class="slide <?= $i === 0 ? 'active' : '' ?>">
            <div class="slide-content">
                <h1 class="slide-title"><?= $s['title'] ?></h1>
                <p class="slide-subtitle"><?= $s['sub'] ?></p>
                <a href="<?= base_url('products?category=' . $s['cat']) ?>" class="slide-btn">
                    Shop <?= explode(' ', $s['title'])[count(explode(' ', $s['title'])) - 1] ?> Tea
                </a>
            </div>
        </div>
    <?php endforeach; ?>

    <div class="slide-dots">
        <?php for ($i = 0; $i < count($slides); $i++): ?>
            <button class="dot <?= $i === 0 ? 'active' : '' ?>" data-index="<?= $i ?>"></button>
        <?php endfor; ?>
    </div>
</section>

<!-- NEW ARRIVALS -->
<section class="best-seller">
    <div class="container">
        <h2 class="section-title">New Arrivals</h2>
        <div class="product-container">
            <?php foreach ($newArrivals ?? [] as $product): ?>
                <div class="product-card" onclick="location.href='<?= base_url('products/' . $product['slug']) ?>'">

                    <?php if (!empty($product['sale_price'])): ?>
                        <div class="sale-badge">Sale</div>
                    <?php endif; ?>

                    <div class="image-box">
                        <?php $imgSrc = str_starts_with($product['image'], 'http') ? $product['image'] : base_url('images/products/' . $product['image']); ?>
                        <img src="<?= $imgSrc ?>" alt="<?= esc($product['name']) ?>">
                    </div>

                    <h3><?= esc($product['name']) ?></h3>

                    <div class="price">
                        <?php if (!empty($product['sale_price'])): ?>
                            <span class="new">₹<?= number_format($product['sale_price']) ?></span>
                            <span class="old">₹<?= number_format($product['price']) ?></span>
                        <?php else: ?>
                            <span class="new">₹<?= number_format($product['price']) ?></span>
                        <?php endif; ?>
                    </div>

                    <button class="add-to-cart-btn add-to-cart" data-id="<?= $product['id'] ?>" onclick="event.stopPropagation();">Add to Cart</button>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- BEST SELLERS -->
<section class="best-seller-section">
    <div class="container">
        <h2 class="section-title">Best Sellers</h2>
        <div class="best-seller-grid">
            <?php foreach (array_slice($bestSellers ?? [], 0, 8) as $product): ?>
                <div class="bs-card">
                    <div class="bs-image">
                        <img src="<?= base_url('images/products/' . $product['image']) ?>" alt="<?= esc($product['name']) ?>">
                        <div class="bs-hover">
                           <button class="add-to-cart-btn add-to-cart" data-id="<?= $product['id'] ?>" onclick="event.stopPropagation();">Add to Cart</button>
                        </div>
                    </div>
                    <h5><?= esc($product['name']) ?></h5>
                    <div class="bs-price">
                        <?php if (!empty($product['sale_price'])): ?>
                            <span class="new">₹<?= number_format($product['sale_price']) ?></span>
                            <span class="old">₹<?= number_format($product['price']) ?></span>
                        <?php else: ?>
                            <span class="new">₹<?= number_format($product['price']) ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ABOUT -->
<section class="about-section" id="about">
    <div class="container">
        <div class="about-wrapper">
            <div class="about-left">
                <div class="about-content">
                    <h2>About Our Tea Haven</h2>
                    <p>We bring you the finest handpicked tea leaves sourced directly from the most renowned tea gardens. Our mission is to deliver freshness, rich aroma, and authentic taste in every cup.</p>
                    <p>Every blend is crafted with passion to ensure premium quality and an unforgettable tea experience — from the first sip to the last.</p>
                    <a href="<?= base_url('products') ?>" class="about-btn">Shop Now</a>
                </div>
            </div>
            <div class="about-right">
                <div class="about-image">
                    <img src="https://images.unsplash.com/photo-1509042239860-f550ce710b93" alt="Premium Tea">
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CATEGORIES -->
<section class="tea-category-section">
    <h2 class="section-title">Shop by Category</h2>
    <div class="tea-container">
        <?php foreach ($categories ?? [] as $cat): ?>
            <div class="tea-card">
                <img src="<?= base_url('images/categories/' . $cat['image']) ?>" alt="<?= esc($cat['name']) ?>">
                <div class="tea-overlay">
                    <h3><?= esc($cat['name']) ?></h3>
                    <a href="<?= base_url('products?category=' . $cat['slug']) ?>">SHOP NOW</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<?php
$footer_scripts = '
<script src="' . base_url('js/cart.js') . '"></script>
<script>
// Hero Slider
let slides = document.querySelectorAll(".slide");
let dots   = document.querySelectorAll(".dot");
let idx    = 0;

function showSlide(i) {
    slides.forEach(s => s.classList.remove("active"));
    dots.forEach(d => d.classList.remove("active"));
    slides[i].classList.add("active");
    dots[i].classList.add("active");
    idx = i;
}

dots.forEach((dot, i) => dot.addEventListener("click", () => showSlide(i)));
setInterval(() => showSlide((idx + 1) % slides.length), 5000);
</script>
';
echo view('layouts/footer', compact('footer_scripts'));
?>