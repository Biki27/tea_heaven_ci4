
<footer class="site-footer">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-6 mb-4">
                <h6>About Tea Haven</h6>
                <p>We bring you the finest handpicked tea leaves sourced directly from the most renowned tea gardens across India, China, and Japan. Our mission is to deliver freshness, rich aroma, and authentic taste in every cup.</p>
            </div>
            <div class="col-6 col-md-3 mb-4">
                <h6>Categories</h6>
                <ul class="footer-links">
                    <li><a href="<?= base_url('products?category=black-tea') ?>">Black Tea</a></li>
                    <li><a href="<?= base_url('products?category=green-tea') ?>">Green Tea</a></li>
                    <li><a href="<?= base_url('products?category=herbal') ?>">Herbal Tea</a></li>
                    <li><a href="<?= base_url('products?category=oolong') ?>">Oolong Tea</a></li>
                    <li><a href="<?= base_url('products?category=white-tea') ?>">White Tea</a></li>
                </ul>
            </div>
            <div class="col-6 col-md-3 mb-4">
                <h6>Quick Links</h6>
                <ul class="footer-links">
                    <li><a href="<?= base_url('#about') ?>">About Us</a></li>
                    <li><a href="<?= base_url('#contact') ?>">Contact Us</a></li>
                    <li><a href="<?= base_url('orders') ?>">Track Order</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Shipping Policy</a></li>
                </ul>
            </div>
        </div>
        <hr>
        <div class="row align-items-center">
            <div class="col-lg-8 col-12">
                <p class="copyright-text">Copyright &copy; <?= date('Y') ?> All Rights Reserved by <a href="#">Tea Haven</a>.</p>
            </div>
            <div class="col-lg-4 col-12">
                <ul class="social-icons">
                    <li><a class="facebook" href="#" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a class="twitter" href="#" title="Twitter"><i class="fab fa-twitter"></i></a></li>
                    <li><a class="instagram" href="#" title="Instagram"><i class="fab fa-instagram"></i></a></li>
                    <li><a class="linkedin" href="#" title="LinkedIn"><i class="fab fa-linkedin-in"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<?= $footer_scripts ?? '' ?>
</body>
<?php if (isset($footer_scripts)): ?>
        <?= $footer_scripts ?>
    <?php endif; ?>
</html>

<style>
.site-footer { background-color:#26272b; padding:45px 0 20px; font-size:15px; line-height:24px; color:#737373; }
.site-footer hr { border-top-color:#bbb; opacity:0.5; }
.site-footer h6 { color:#fff; font-size:16px; text-transform:uppercase; margin-top:5px; letter-spacing:2px; }
.site-footer a { color:#737373; }
.site-footer a:hover { color:#3366cc; text-decoration:none; }
.footer-links { padding-left:0; list-style:none; }
.footer-links li { display:block; padding:3px 0; }
.site-footer .social-icons { text-align:right; padding-left:0; list-style:none; margin:0; }
.site-footer .social-icons li { display:inline-block; margin-bottom:4px; }
.site-footer .social-icons a { width:40px; height:40px; line-height:40px; margin-left:6px; border-radius:100%; background-color:#33353d; color:#818a91!important; font-size:16px; display:inline-block; text-align:center; text-decoration:none; transition:all .2s linear; }
.site-footer .social-icons a:hover { color:#fff!important; background-color:#29aafe; }
.site-footer .social-icons a.facebook:hover { background-color:#3b5998; }
.site-footer .social-icons a.twitter:hover { background-color:#00aced; }
.site-footer .social-icons a.instagram:hover { background-color:#e4405f; }
.site-footer .social-icons a.linkedin:hover { background-color:#007bb6; }
.copyright-text { margin:0; }
@media (max-width:767px) { .site-footer .copyright-text, .site-footer .social-icons { text-align:center; } }
</style>
