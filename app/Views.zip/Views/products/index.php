<?php
$extra_css = '
body { padding-top: 80px; background:#f8f9fa; font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, sans-serif; }
:root { --bg:#ffffff; --muted:#666; --accent:#111; --leaf-green:#6B8E23; --warm-brown:#4E342E; }
a { color:inherit; text-decoration:none; }
img { max-width:100%; display:block; }

.products-wrapper { width:min(1200px,94%); margin:0 auto; padding:28px 0; display:grid; grid-template-columns:260px 1fr; gap:28px; }
@media(max-width:900px){ .products-wrapper{ grid-template-columns:1fr; } .sidebar{ display:none; } }

/* SIDEBAR */
.sidebar { position:sticky; top:90px; font-size:14px; align-self:start; }
.facet { background:#fff; border:1px solid #f0f0f0; padding:16px; border-radius:10px; margin-bottom:14px; box-shadow:0 2px 8px rgba(0,0,0,0.04); }
.facet h4 { margin:0 0 12px; font-weight:600; font-size:15px; color:#222; border-bottom:2px solid var(--leaf-green); padding-bottom:8px; }
.facet label { display:flex; align-items:center; gap:8px; margin:8px 0; cursor:pointer; color:#555; font-size:13px; }
.facet label:hover { color:var(--leaf-green); }
.facet input[type="checkbox"], .facet input[type="radio"] { accent-color:var(--leaf-green); width:15px; height:15px; }
.facet select { width:100%; padding:8px; border:1px solid #e0e0e0; border-radius:6px; font-size:13px; color:#333; }
.filter-btn { width:100%; padding:10px; background:var(--leaf-green); color:white; border:none; border-radius:8px; font-weight:600; cursor:pointer; margin-top:10px; transition:0.2s; }
.filter-btn:hover { background:var(--warm-brown); }
.clear-link { display:block; text-align:center; margin-top:8px; color:#999; font-size:12px; }
.clear-link:hover { color:var(--leaf-green); }

/* CONTROLS */
.controls-bar { display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; flex-wrap:wrap; gap:10px; }
.results-count { font-size:14px; color:var(--muted); }
.category-tabs { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:20px; }
.cat-tab { padding:6px 16px; border-radius:20px; border:1px solid #ddd; background:#fff; font-size:13px; font-weight:500; cursor:pointer; transition:all 0.2s; text-decoration:none; color:#555; }
.cat-tab:hover, .cat-tab.active { background:var(--leaf-green); color:#fff; border-color:var(--leaf-green); }

/* PRODUCT GRID */
.product-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:18px; }
@media(max-width:1100px){ .product-grid{ grid-template-columns:repeat(3,1fr); } }
@media(max-width:800px){ .product-grid{ grid-template-columns:repeat(2,1fr); } }
@media(max-width:480px){ .product-grid{ grid-template-columns:1fr; } }

.prod-card { background:#fff; border-radius:10px; box-shadow:0 4px 15px rgba(0,0,0,0.06); overflow:hidden; display:flex; flex-direction:column; transition:all 0.3s ease; }
.prod-card:hover { transform:translateY(-6px); box-shadow:0 15px 40px rgba(0,0,0,0.12); }
.prod-card .media { aspect-ratio:1/1.1; overflow:hidden; display:block; position:relative; }
.prod-card .media img { width:100%; height:100%; object-fit:cover; transition:transform .35s ease; }
.prod-card:hover .media img { transform:scale(1.06); }
.badge-sale { position:absolute; top:10px; left:10px; background:#e53935; color:#fff; font-size:11px; font-weight:700; padding:3px 10px; border-radius:12px; }
.badge-new  { position:absolute; top:10px; left:10px; background:#2196f3; color:#fff; font-size:11px; font-weight:700; padding:3px 10px; border-radius:12px; }
.prod-card .meta { padding:14px; flex:1; display:flex; flex-direction:column; }
.prod-name { font-weight:600; font-size:14px; color:#222; margin-bottom:6px; }
.prod-cat  { font-size:11px; color:#999; margin-bottom:8px; text-transform:uppercase; letter-spacing:0.5px; }
.prod-price { margin-bottom:12px; }
.prod-price .new { color:var(--leaf-green); font-weight:700; font-size:16px; }
.prod-price .old { text-decoration:line-through; color:#aaa; font-size:13px; margin-left:6px; }
.prod-stars { color:#f4b400; font-size:12px; margin-bottom:10px; }
.prod-actions { display:flex; gap:8px; margin-top:auto; }
.btn-cart { flex:1; padding:9px 12px; background:var(--leaf-green); color:#fff; border:none; border-radius:6px; font-size:13px; font-weight:600; cursor:pointer; transition:0.25s; }
.btn-cart:hover { background:var(--warm-brown); }
.btn-view { padding:9px 12px; border:1px solid #ddd; background:#fff; border-radius:6px; font-size:13px; cursor:pointer; transition:0.25s; color:#555; text-decoration:none; display:flex; align-items:center; }
.btn-view:hover { border-color:#111; background:#f5f5f5; }

/* PAGINATION */
.pagination-wrap { display:flex; justify-content:center; gap:8px; margin-top:40px; flex-wrap:wrap; }
.page-btn { width:38px; height:38px; border-radius:8px; border:1px solid #ddd; background:#fff; cursor:pointer; font-size:14px; transition:0.2s; display:flex; align-items:center; justify-content:center; }
.page-btn:hover, .page-btn.active { background:var(--leaf-green); color:#fff; border-color:var(--leaf-green); }

/* EMPTY */
.empty-state { text-align:center; padding:60px 20px; color:var(--muted); }
.empty-state i { font-size:60px; opacity:0.3; margin-bottom:20px; display:block; }
';
echo view('layouts/header', compact('extra_css') + ['title' => 'Products — Tea Haven', 'cartCount' => $cartCount ?? 0, 'search' => $search ?? '']);
?>

<div class="products-wrapper">

    <!-- SIDEBAR FILTERS -->
    <aside class="sidebar">
        <form method="GET" action="<?= base_url('products') ?>">
            <div class="facet">
                <h4>Category</h4>
                <?php foreach ($categories ?? [] as $cat): ?>
                    <label>
                        <input type="checkbox" name="category[]" value="<?= esc($cat['slug']) ?>"
                            <?= in_array($cat['slug'], (array)($activeCategories ?? [])) ? 'checked' : '' ?>>
                        <?= esc($cat['name']) ?> (<?= $cat['count'] ?? 0 ?>)
                    </label>
                <?php endforeach; ?>
            </div>

            <div class="facet">
                <h4>Price Range</h4>
                <label><input type="radio" name="price" value="all" <?= ($priceFilter ?? 'all') === 'all' ? 'checked' : '' ?>> All Prices</label>
                <label><input type="radio" name="price" value="0-200"   <?= ($priceFilter ?? '') === '0-200'   ? 'checked' : '' ?>> Under ₹200</label>
                <label><input type="radio" name="price" value="200-500" <?= ($priceFilter ?? '') === '200-500' ? 'checked' : '' ?>> ₹200 – ₹500</label>
                <label><input type="radio" name="price" value="500-999" <?= ($priceFilter ?? '') === '500-999' ? 'checked' : '' ?>> ₹500 – ₹999</label>
                <label><input type="radio" name="price" value="1000+"   <?= ($priceFilter ?? '') === '1000+'   ? 'checked' : '' ?>> ₹1000+</label>
            </div>

            <div class="facet">
                <h4>Sort By</h4>
                <select name="sort">
                    <option value="popular"    <?= ($sort ?? '') === 'popular'    ? 'selected' : '' ?>>Most Popular</option>
                    <option value="new"        <?= ($sort ?? '') === 'new'        ? 'selected' : '' ?>>Newest First</option>
                    <option value="price_asc"  <?= ($sort ?? '') === 'price_asc'  ? 'selected' : '' ?>>Price: Low → High</option>
                    <option value="price_desc" <?= ($sort ?? '') === 'price_desc' ? 'selected' : '' ?>>Price: High → Low</option>
                </select>
            </div>

            <?php if (!empty($search)): ?>
                <input type="hidden" name="search" value="<?= esc($search) ?>">
            <?php endif; ?>

            <button type="submit" class="filter-btn"><i class="fas fa-filter"></i> Apply Filters</button>
            <a href="<?= base_url('products') ?>" class="clear-link">Clear all filters</a>
        </form>
    </aside>

    <!-- MAIN CONTENT -->
    <section>
        <!-- Category Quick Tabs -->
        <div class="category-tabs">
            <a href="<?= base_url('products') ?>" class="cat-tab <?= empty($activeCategories) ? 'active' : '' ?>">All</a>
            <?php foreach ($categories ?? [] as $cat): ?>
                <a href="<?= base_url('products?category=' . $cat['slug']) ?>"
                   class="cat-tab <?= in_array($cat['slug'], (array)($activeCategories ?? [])) ? 'active' : '' ?>">
                    <?= esc($cat['name']) ?>
                </a>
            <?php endforeach; ?>
        </div>

        <!-- Controls Bar -->
        <div class="controls-bar">
            <span class="results-count">
                Showing <?= count($products ?? []) ?> of <?= $totalProducts ?? 0 ?> products
                <?= !empty($search) ? ' for "' . esc($search) . '"' : '' ?>
            </span>
        </div>

        <!-- Product Grid -->
        <?php if (!empty($products)): ?>
            <div class="product-grid">
                <?php foreach ($products as $p): ?>
                    <article class="prod-card">
                        <a class="media" href="<?= base_url('products/' . $p['slug']) ?>">
                            <?php $imgSrc = str_starts_with($p['image'], 'http') ? $p['image'] : base_url('images/products/' . $p['image']); ?>
                            <img src="<?= $imgSrc ?>" alt="<?= esc($p['name']) ?>" loading="lazy">
                            
                            <?php if (!empty($p['sale_price'])): ?>
                                <span class="badge-sale">Sale</span>
                            <?php elseif ($p['is_new'] ?? false): ?>
                                <span class="badge-new">New</span>
                            <?php endif; ?>
                        </a>
                        <div class="meta">
                            <div class="prod-cat"><?= esc($p['category_name'] ?? '') ?></div>
                            <div class="prod-name"><?= esc($p['name']) ?></div>
                            
                            <?php if ($p['rating'] ?? false): ?>
                                <div class="prod-stars">
                                    <?= str_repeat('★', round($p['rating'])) . str_repeat('☆', 5 - round($p['rating'])) ?>
                                    <span style="color:#999; font-size:11px;">(<?= $p['review_count'] ?? 0 ?>)</span>
                                </div>
                            <?php endif; ?>
                            
                            <div class="prod-price">
                                <?php if (!empty($p['sale_price'])): ?>
                                    <span class="new">₹<?= number_format($p['sale_price']) ?></span>
                                    <span class="old">₹<?= number_format($p['price']) ?></span>
                                <?php else: ?>
                                    <span class="new">₹<?= number_format($p['price']) ?></span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="prod-actions">
                                <button class="btn-cart add-to-cart" data-id="<?= $p['id'] ?>" onclick="event.stopPropagation();">
                                    <i class="fas fa-cart-plus"></i> Add to Cart
                                </button>
                                <a href="<?= base_url('products/' . $p['slug']) ?>" class="btn-view" title="View product" onclick="event.stopPropagation();">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>>
            </div>

            <!-- Pagination -->
            <?php if (($totalPages ?? 1) > 1): ?>
                <div class="pagination-wrap">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="<?= base_url('products?page=' . $i . '&' . http_build_query(array_filter(['search' => $search ?? '', 'sort' => $sort ?? '', 'price' => $priceFilter ?? '']))) ?>"
                           class="page-btn <?= ($currentPage ?? 1) === $i ? 'active' : '' ?>"><?= $i ?></a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>

        <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-search"></i>
                <h3>No products found</h3>
                <p>Try adjusting your filters or search terms</p>
                <a href="<?= base_url('products') ?>" style="color:var(--leaf-green);">Browse all products →</a>
            </div>
        <?php endif; ?>
    </section>
</div>

<?php
$footer_scripts = '<script src="' . base_url('js/cart.js') . '"></script>';
echo view('layouts/footer', compact('footer_scripts'));
?>
