<?php helper('form'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In / Sign Up — Tea Haven</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,800" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css?family=Montserrat:400,800');
        * { box-sizing:border-box; }
        body { background:#f6f5f7; display:flex; justify-content:center; align-items:center; flex-direction:column; font-family:'Montserrat',sans-serif; min-height:100vh; margin:0; padding:20px; }
        h1 { font-weight:bold; margin:0; }
        h2 { text-align:center; color:#333; margin-bottom:20px; }
        p { font-size:14px; font-weight:100; line-height:20px; letter-spacing:0.5px; margin:20px 0 30px; }
        span { font-size:12px; }
        a { color:#333; font-size:14px; text-decoration:none; margin:15px 0; }
        button { border-radius:20px; border:1px solid #6B8E23; background-color:#6B8E23; color:#FFFFFF; font-size:12px; font-weight:bold; padding:12px 45px; letter-spacing:1px; text-transform:uppercase; transition:transform 80ms ease-in; cursor:pointer; }
        button:active { transform:scale(0.95); }
        button:focus { outline:none; }
        button.ghost { background-color:transparent; border-color:#FFFFFF; }
        form { background-color:#FFFFFF; display:flex; align-items:center; justify-content:center; flex-direction:column; padding:0 50px; height:100%; text-align:center; }
        input[type="text"], input[type="email"], input[type="password"] { background-color:#eee; border:none; padding:12px 15px; margin:8px 0; width:100%; border-radius:4px; font-size:14px; }
        input:focus { outline:2px solid #6B8E23; }

        .container { background-color:#fff; border-radius:10px; box-shadow:0 14px 28px rgba(0,0,0,0.25),0 10px 10px rgba(0,0,0,0.22); position:relative; overflow:hidden; width:768px; max-width:100%; min-height:480px; }
        .form-container { position:absolute; top:0; height:100%; transition:all 0.6s ease-in-out; }
        .sign-in-container { left:0; width:50%; z-index:2; }
        .container.right-panel-active .sign-in-container { transform:translateX(100%); }
        .sign-up-container { left:0; width:50%; opacity:0; z-index:1; }
        .container.right-panel-active .sign-up-container { transform:translateX(100%); opacity:1; z-index:5; animation:show 0.6s; }
        @keyframes show { 0%,49.99%{opacity:0;z-index:1;} 50%,100%{opacity:1;z-index:5;} }
        .overlay-container { position:absolute; top:0; left:50%; width:50%; height:100%; overflow:hidden; transition:transform 0.6s ease-in-out; z-index:100; }
        .container.right-panel-active .overlay-container { transform:translateX(-100%); }
        .overlay { background:linear-gradient(to right,#6B8E23,#4a6a1a); color:#FFFFFF; position:relative; left:-100%; height:100%; width:200%; transform:translateX(0); transition:transform 0.6s ease-in-out; }
        .container.right-panel-active .overlay { transform:translateX(50%); }
        .overlay-panel { position:absolute; display:flex; align-items:center; justify-content:center; flex-direction:column; padding:0 40px; text-align:center; top:0; height:100%; width:50%; transform:translateX(0); transition:transform 0.6s ease-in-out; }
        .overlay-left { transform:translateX(-20%); }
        .container.right-panel-active .overlay-left { transform:translateX(0); }
        .overlay-right { right:0; transform:translateX(0); }
        .container.right-panel-active .overlay-right { transform:translateX(20%); }
        .social-container { margin:20px 0; }
        .social-container a { border:1px solid #DDDDDD; border-radius:50%; display:inline-flex; justify-content:center; align-items:center; margin:0 5px; height:40px; width:40px; color:#333; transition:all 0.3s ease; text-decoration:none; }
        .social-container a:hover { background-color:#f0f0f0; transform:translateY(-2px); }
        .error-msg { background:#ffe0e0; color:#c0392b; border-radius:8px; padding:10px 18px; margin-bottom:12px; font-size:13px; width:100%; text-align:left; }
        .success-msg { background:#e0ffe0; color:#27ae60; border-radius:8px; padding:10px 18px; margin-bottom:12px; font-size:13px; width:100%; text-align:left; }
        .forgot-link { font-size:12px; color:#999; margin-top:5px; }
        .forgot-link:hover { color:#6B8E23; }
        .divider { display:flex; align-items:center; width:100%; gap:10px; margin:10px 0; color:#aaa; font-size:12px; }
        .divider::before, .divider::after { content:""; flex:1; height:1px; background:#ddd; }
        .oauth-btn { display:flex; align-items:center; gap:10px; justify-content:center; width:100%; padding:10px 20px; border-radius:20px; border:1px solid #ddd; background:#fff; color:#333; font-size:13px; font-weight:600; margin:5px 0; cursor:pointer; transition:all 0.2s; }
        .oauth-btn:hover { background:#f5f5f5; transform:translateY(-1px); box-shadow:0 4px 12px rgba(0,0,0,0.1); }
        .oauth-google { border-color:#ea4335; }
        .oauth-facebook { border-color:#3b5998; }
        @media(max-width:600px) { .container { min-height:600px; } form { padding:0 20px; } }
    </style>
</head>
<body>
    <h2>Tea Haven — Sign In / Sign Up</h2>

    <div class="container" id="container">

        <div class="form-container sign-up-container">
            <form action="<?= base_url('auth/register') ?>" method="POST">
                <?= csrf_field() ?>
                <h1>Create Account</h1>

                <?php if (session()->getFlashdata('register_error')): ?>
                    <div class="error-msg"><?= session()->getFlashdata('register_error') ?></div>
                <?php endif; ?>

                <div class="social-container">
                    <a href="<?= base_url('auth/google') ?>" class="social oauth-btn oauth-google" title="Google">
                        <i class="fab fa-google"></i> Google
                    </a>
                    <a href="<?= base_url('auth/facebook') ?>" class="social oauth-btn oauth-facebook" title="Facebook">
                        <i class="fab fa-facebook-f"></i> Facebook
                    </a>
                </div>
                <div class="divider">or use email</div>

                <input type="text" name="name" placeholder="Full Name" value="<?= old('name') ?>" required />
                <input type="email" name="email" placeholder="Email" value="<?= old('email') ?>" required />
                <input type="password" name="password" placeholder="Password (min 8 chars)" required />
                <input type="password" name="confirm_password" placeholder="Confirm Password" required />
                <button type="submit">Sign Up</button>
            </form>
        </div>

        <div class="form-container sign-in-container">
            <form action="<?= base_url('auth/login') ?>" method="POST">
                <?= csrf_field() ?>
                <h1>Sign In</h1>

                <?php if (session()->getFlashdata('error')): ?>
                    <div class="error-msg"><?= session()->getFlashdata('error') ?></div>
                <?php endif; ?>
                <?php if (session()->getFlashdata('success')): ?>
                    <div class="success-msg"><?= session()->getFlashdata('success') ?></div>
                <?php endif; ?>

                <div class="social-container">
                    <a href="<?= base_url('auth/google') ?>" class="oauth-btn oauth-google" title="Google">
                        <i class="fab fa-google"></i> Google
                    </a>
                    <a href="<?= base_url('auth/facebook') ?>" class="oauth-btn oauth-facebook" title="Facebook">
                        <i class="fab fa-facebook-f"></i> Facebook
                    </a>
                </div>
                <div class="divider">or use your account</div>

                <input type="email" name="email" placeholder="Email" value="<?= old('email') ?>" required />
                <input type="password" name="password" placeholder="Password" required />
                <a href="<?= base_url('auth/forgot') ?>" class="forgot-link">Forgot your password?</a>
                <button type="submit">Sign In</button>
            </form>
        </div>

        <div class="overlay-container">
            <div class="overlay">
                <div class="overlay-panel overlay-left">
                    <h1>Welcome Back!</h1>
                    <p>To keep connected with us please login with your personal info</p>
                    <button class="ghost" id="signIn">Sign In</button>
                </div>
                <div class="overlay-panel overlay-right">
                    <h1>Hello, Friend!</h1>
                    <p>Enter your personal details and start your tea journey with us</p>
                    <button class="ghost" id="signUp">Sign Up</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        const signUpButton  = document.getElementById('signUp');
        const signInButton  = document.getElementById('signIn');
        const container     = document.getElementById('container');

        signUpButton.addEventListener('click', () => container.classList.add('right-panel-active'));
        signInButton.addEventListener('click', () => container.classList.remove('right-panel-active'));

        // Auto-switch to register panel if there was a register error
        <?php if (session()->getFlashdata('register_error') || old('name')): ?>
            container.classList.add('right-panel-active');
        <?php endif; ?>
    </script>
</body>
</html>