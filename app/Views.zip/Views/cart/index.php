<?php
// Initialize view variables missing from the controller
$shipping = 50; 
$promoCode = session()->get('promo_code') ?? '';
$discount = session()->get('promo_discount') ?? 0;
// Prevent total from dipping below zero
$finalTotal = max(0, $total - $discount);

$extra_css = '
body { padding-top: 90px; background: #f8f9fa; }
:root { --leaf-green: #6B8E23; --tea-gold: #D4AF37; --warm-brown: #8B4513; }

.cart-container { max-width:1100px; margin:0 auto; padding:2rem 1rem; }
.cart-header { background:linear-gradient(135deg,var(--leaf-green),#90C695); color:white; padding:2rem; border-radius:20px; margin-bottom:2rem; text-align:center; box-shadow:0 10px 40px rgba(107,142,35,0.3); }
.cart-item { background:white; border-radius:16px; padding:1.5rem; margin-bottom:1rem; box-shadow:0 5px 20px rgba(0,0,0,0.08); display:flex; align-items:center; transition:all 0.3s ease; }
.cart-item:hover { box-shadow:0 15px 40px rgba(0,0,0,0.15); transform:translateY(-2px); }
.cart-image { width:100px; height:100px; border-radius:12px; object-fit:cover; margin-right:1.5rem; box-shadow:0 5px 15px rgba(0,0,0,0.1); flex-shrink:0; }
.cart-details { flex:1; }
.cart-name { font-size:1.2rem; font-weight:600; color:var(--warm-brown); margin-bottom:0.4rem; }
.cart-desc { color:#7d7d7d; font-size:0.9rem; margin-bottom:0.8rem; line-height:1.5; }
.cart-price { font-size:1.3rem; font-weight:bold; color:var(--leaf-green); }
.quantity-section { display:flex; align-items:center; margin-left:auto; flex-shrink:0; }
.quantity-control { display:flex; align-items:center; gap:0.5rem; background:#f8f9fa; padding:0.5rem; border-radius:25px; }
.qty-btn { width:38px; height:38px; border:none; background:white; border-radius:50%; font-size:1.1rem; cursor:pointer; transition:all 0.2s; display:flex; align-items:center; justify-content:center; font-weight:bold; }
.qty-btn:hover { background:var(--leaf-green); color:white; transform:scale(1.1); }
.qty-input { width:55px; height:38px; border:none; text-align:center; font-weight:600; font-size:1rem; background:transparent; }
.remove-btn { width:40px; height:40px; border-radius:50%; background:#f8f9fa; border:none; color:#999; font-size:1rem; cursor:pointer; transition:all 0.3s; display:flex; align-items:center; justify-content:center; margin-left:0.8rem; }
.remove-btn:hover { background:#ff4757; color:white; transform:scale(1.1); }

.cart-summary { background:white; border-radius:20px; padding:2rem; box-shadow:0 10px 40px rgba(0,0,0,0.08); height:fit-content; position:sticky; top:100px; }
.promo-section { background:linear-gradient(135deg,#f8f9fa,#e9ecef); padding:1.5rem; border-radius:16px; margin-bottom:1.5rem; }
.promo-input { border:2px solid #e1e5e9; border-radius:25px 0 0 25px; padding:10px 14px; outline:none; font-size:14px; }
.promo-btn { border-radius:0 25px 25px 0; background:var(--leaf-green); border:none; color:white; padding:10px 18px; cursor:pointer; font-weight:600; transition:0.2s; }
.promo-btn:hover { background:var(--warm-brown); }
.promo-msg { font-size:13px; margin-top:8px; padding:6px 10px; border-radius:6px; }
.promo-success { background:#e0ffe0; color:#27ae60; }
.promo-error   { background:#ffe0e0; color:#c0392b; }

.summary-list { list-style:none; padding:0; margin:0; }
.summary-list li { display:flex; justify-content:space-between; align-items:center; padding:0.9rem 0; border-bottom:1px solid #eee; font-size:15px; }
.summary-list li:last-child { border-bottom:none; }
.summary-total { font-size:1.5rem; font-weight:bold; color:var(--leaf-green); border-top:2px solid var(--leaf-green)!important; padding-top:1rem!important; margin-top:0.5rem; }
.checkout-btn { width:100%; padding:15px; background:linear-gradient(135deg,var(--leaf-green),#90C695); border:none; border-radius:50px; color:white; font-size:1.1rem; font-weight:600; cursor:pointer; transition:all 0.3s; box-shadow:0 8px 25px rgba(107,142,35,0.3); display:block; text-align:center; text-decoration:none; margin-top:16px; }
.checkout-btn:hover { transform:translateY(-2px); box-shadow:0 15px 35px rgba(107,142,35,0.4); color:white; }
.continue-btn { display:block; text-align:center; margin-top:12px; color:var(--leaf-green); font-size:14px; text-decoration:none; }
.continue-btn:hover { text-decoration:underline; }

.empty-cart { text-align:center; padding:80px 20px; background:white; border-radius:20px; box-shadow:0 5px 20px rgba(0,0,0,0.06); }
.empty-cart i { font-size:80px; color:#ddd; margin-bottom:20px; display:block; }

@media(max-width:992px) { .cart-item { flex-direction:column; text-align:center; gap:1rem; } .cart-image { margin-right:0; } .quantity-section { margin-left:0; justify-content:center; width:100%; } }
@media(max-width:576px) { .cart-header h1 { font-size:1.6rem; } .cart-name { font-size:1rem; } }
';
echo view('layouts/header', compact('extra_css') + ['title' => 'Shopping Cart — Tea Haven', 'cartCount' => $cartCount ?? 0]);
?>

<div class="cart-container">
    <div class="cart-header">
        <h1><i class="fas fa-shopping-cart me-3"></i>Shopping Cart</h1>
        <p class="mb-0">
            <?= count($items ?? []) > 0
                ? count($items) . ' item(s) in your cart'
                : 'Your cart is empty' ?>
        </p>
    </div>

    <?php if (!empty($items)): ?>
        <div class="row g-4">
            <div class="col-lg-8">
                <?php foreach ($items as $item): ?>
                    <?php 
                        // Fix for Image Links and Pricing
                        $imgSrc = str_starts_with($item['image'], 'http') ? $item['image'] : base_url('images/products/' . $item['image']); 
                        $displayPrice = $item['sale_price'] > 0 ? $item['sale_price'] : $item['price'];
                    ?>
                    
                    <div class="cart-item" id="cart-item-<?= $item['id'] ?>">
                        <img src="<?= $imgSrc ?>" alt="<?= esc($item['name']) ?>" class="cart-image">
                        <div class="cart-details">
                            <h4 class="cart-name"><?= esc($item['name']) ?></h4>
                            <p class="cart-desc"><?= esc($item['description'] ?? '') ?></p>
                            <div class="cart-price">₹<?= number_format($displayPrice) ?></div>
                        </div>
                        <div class="quantity-section ms-auto d-flex align-items-center">
                            <div class="quantity-control">
                                <button class="qty-btn qty-decrease"
                                        data-id="<?= $item['id'] ?>"
                                        data-qty="<?= $item['quantity'] ?>">−</button>
                                <input type="number" class="qty-input" value="<?= $item['quantity'] ?>"
                                       min="1" max="99" data-id="<?= $item['id'] ?>">
                                <button class="qty-btn qty-increase"
                                        data-id="<?= $item['id'] ?>"
                                        data-qty="<?= $item['quantity'] ?>">+</button>
                            </div>
                            <button class="remove-btn remove-item" data-id="<?= $item['id'] ?>" title="Remove">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="col-lg-4">
                <div class="cart-summary">
                    <div class="promo-section">
                        <label class="fw-bold mb-2 d-block">Have a Promo Code?</label>
                        <div class="d-flex">
                            <input type="text" id="promoCode" class="promo-input flex-grow-1"
                                   placeholder="Enter code" value="<?= esc($promoCode) ?>">
                            <button class="promo-btn" id="applyPromo">Apply</button>
                        </div>
                        <div id="promoMsg" class="promo-msg" style="display:none;"></div>
                    </div>

                    <ul class="summary-list">
                        <li>
                            Subtotal
                            <span id="cart-subtotal">₹<?= number_format($subtotal ?? 0) ?></span>
                        </li>
                        <?php if ($discount > 0): ?>
                            <li style="color:#27ae60;">
                                Discount (<?= esc($promoCode) ?>)
                                <span>−₹<?= number_format($discount) ?></span>
                            </li>
                        <?php endif; ?>
                        <li>
                            Tax (GST 5%)
                            <span id="cart-tax">₹<?= number_format($tax ?? 0) ?></span>
                        </li>
                        <li>
                            Shipping
                            <span><?= $shipping > 0 ? '₹' . number_format($shipping) : '<span style="color:#27ae60;">FREE</span>' ?></span>
                        </li>
                        <li class="summary-total fw-bold">
                            Total
                            <span id="cart-total">₹<?= number_format($finalTotal) ?></span>
                        </li>
                    </ul>

                    <?php if (session()->get('user_id')): ?>
                        <a href="<?= base_url('checkout') ?>" class="checkout-btn">
                            <i class="fas fa-credit-card me-2"></i> Proceed to Checkout
                        </a>
                    <?php else: ?>
                        <a href="<?= base_url('auth/login') ?>" class="checkout-btn">
                            <i class="fas fa-sign-in-alt me-2"></i> Login to Checkout
                        </a>
                    <?php endif; ?>

                    <a href="<?= base_url('products') ?>" class="continue-btn">
                        <i class="fas fa-arrow-left me-1"></i> Continue Shopping
                    </a>
                </div>
            </div>
        </div>

    <?php else: ?>
        <div class="empty-cart">
            <i class="fas fa-shopping-basket"></i>
            <h3>Your cart is empty</h3>
            <p class="text-muted mb-4">Add some premium teas to get started!</p>
            <a href="<?= base_url('products') ?>" class="checkout-btn" style="display:inline-block; width:auto; padding:14px 40px;">
                <i class="fas fa-leaf me-2"></i> Browse Teas
            </a>
        </div>
    <?php endif; ?>
</div>

<?php
$footer_scripts = '
<script>
const CSRF_TOKEN = "' . csrf_hash() . '";
const CSRF_NAME  = "' . csrf_token() . '";

// Qty decrease
document.querySelectorAll(".qty-decrease").forEach(btn => {
    btn.addEventListener("click", () => {
        const id  = btn.dataset.id;
        const qty = parseInt(document.querySelector(`.qty-input[data-id="${id}"]`).value);
        if (qty > 1) updateQty(id, qty - 1);
    });
});

// Qty increase
document.querySelectorAll(".qty-increase").forEach(btn => {
    btn.addEventListener("click", () => {
        const id  = btn.dataset.id;
        const qty = parseInt(document.querySelector(`.qty-input[data-id="${id}"]`).value);
        updateQty(id, qty + 1);
    });
});

// Qty input change
document.querySelectorAll(".qty-input").forEach(input => {
    input.addEventListener("change", () => updateQty(input.dataset.id, parseInt(input.value)));
});

// Remove item
document.querySelectorAll(".remove-item").forEach(btn => {
    btn.addEventListener("click", () => removeItem(btn.dataset.id));
});

function updateQty(id, qty) {
    const fd = new FormData();
    fd.append("cart_id", id);
    fd.append("qty", qty);
    fd.append(CSRF_NAME, CSRF_TOKEN);

    fetch("' . base_url('cart/update') . '", {
        method: "POST",
        body: fd
    }).then(r => r.json()).then(data => {
        if (data.status === "ok") location.reload();
    });
}

function removeItem(id) {
    const fd = new FormData();
    fd.append("cart_id", id);
    fd.append(CSRF_NAME, CSRF_TOKEN);

    fetch("' . base_url('cart/remove') . '", {
        method: "POST",
        body: fd
    }).then(r => r.json()).then(data => {
        if (data.status === "ok") {
            document.getElementById("cart-item-" + id)?.remove();
            if (!document.querySelector(".cart-item")) location.reload();
        }
    });
}

// Promo code
document.getElementById("applyPromo")?.addEventListener("click", () => {
    const code = document.getElementById("promoCode").value.trim();
    if (!code) return;
    
    const fd = new FormData();
    fd.append("code", code);
    fd.append("total", "' . $total . '"); 
    fd.append(CSRF_NAME, CSRF_TOKEN);

    fetch("' . base_url('cart/promo') . '", {
        method: "POST",
        body: fd
    }).then(r => r.json()).then(data => {
        const msg = document.getElementById("promoMsg");
        msg.style.display = "block";
        if (data.status === "ok") {
            msg.className = "promo-msg promo-success";
            msg.textContent = data.message;
            setTimeout(() => location.reload(), 1200);
        } else {
            msg.className = "promo-msg promo-error";
            msg.textContent = data.message;
        }
    });
});
</script>
';
echo view('layouts/footer', compact('footer_scripts'));
?>