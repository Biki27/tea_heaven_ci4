<?php
$extra_css = '
body { padding-top:90px; background:#f8f9fa; }
:root { --leaf-green:#6B8E23; --tea-gold:#D4AF37; --warm-brown:#4E342E; }
.detail-wrap { max-width:900px; margin:0 auto; padding:2rem 1rem; }
.back-link { color:var(--leaf-green); text-decoration:none; font-size:14px; margin-bottom:1.5rem; display:inline-flex; align-items:center; gap:6px; }
.back-link:hover { text-decoration:underline; color:var(--warm-brown); }
.page-title { font-size:1.6rem; font-weight:700; margin-bottom:1.5rem; color:#222; }
.card-box { background:white; border-radius:16px; box-shadow:0 4px 15px rgba(0,0,0,0.06); padding:1.8rem; margin-bottom:1.5rem; }
.card-box h3 { font-size:1rem; font-weight:700; color:#555; text-transform:uppercase; letter-spacing:0.5px; margin-bottom:1rem; padding-bottom:0.8rem; border-bottom:2px solid #f0f0f0; display:flex; align-items:center; gap:8px; }
.card-box h3 i { color:var(--leaf-green); }
.info-grid { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
@media(max-width:600px){ .info-grid{ grid-template-columns:1fr; } }
.info-item label { font-size:12px; color:#999; text-transform:uppercase; display:block; margin-bottom:3px; }
.info-item span { font-size:14px; font-weight:600; color:#333; }
.badge-status { padding:4px 14px; border-radius:20px; font-size:13px; font-weight:700; text-transform:uppercase; display:inline-block; }
.status-pending    { background:#fff3cd; color:#856404; }
.status-confirmed  { background:#cce5ff; color:#004085; }
.status-processing { background:#cce5ff; color:#004085; }
.status-shipped    { background:#d4edda; color:#155724; }
.status-delivered  { background:#d4edda; color:#155724; }
.status-cancelled  { background:#f8d7da; color:#721c24; }
.order-item-row { display:flex; align-items:center; gap:14px; padding:12px 0; border-bottom:1px solid #f5f5f5; }
.order-item-row:last-child { border-bottom:none; }
.order-item-row img { width:64px; height:64px; border-radius:10px; object-fit:cover; }
.item-info { flex:1; }
.item-info .name { font-weight:600; font-size:14px; }
.item-info .qty  { font-size:12px; color:#999; margin-top:2px; }
.item-price { font-weight:700; color:var(--leaf-green); }
.summary-row { display:flex; justify-content:space-between; padding:9px 0; border-bottom:1px solid #f9f9f9; font-size:14px; }
.summary-row.total-row { font-size:1.1rem; font-weight:800; color:var(--leaf-green); border-top:2px solid var(--leaf-green); border-bottom:none; padding-top:12px; }
.timeline { position:relative; padding-left:30px; }
.timeline::before { content:""; position:absolute; left:10px; top:0; bottom:0; width:2px; background:#e0e0e0; }
.timeline-step { position:relative; margin-bottom:20px; }
.timeline-step::before { content:""; position:absolute; left:-24px; top:3px; width:14px; height:14px; border-radius:50%; background:#ddd; border:2px solid white; box-shadow:0 0 0 2px #ddd; }
.timeline-step.done::before { background:var(--leaf-green); box-shadow:0 0 0 2px var(--leaf-green); }
.timeline-step .step-label { font-weight:600; font-size:14px; color:#333; }
.timeline-step .step-date  { font-size:12px; color:#999; margin-top:2px; }
';
echo view('layouts/header', compact('extra_css') + ['title' => 'Order #' . ($order['order_number'] ?? '') . ' — Tea Haven', 'cartCount' => $cartCount ?? 0]);
?>

<div class="detail-wrap">
    <a href="<?= base_url('orders') ?>" class="back-link">
        <i class="fas fa-arrow-left"></i> Back to My Orders
    </a>
    <h1 class="page-title">Order #<?= esc($order['order_number']) ?></h1>

    <div class="card-box">
        <h3><i class="fas fa-info-circle"></i> Order Info</h3>
        <div class="info-grid">
            <div class="info-item">
                <label>Status</label>
                <span class="badge-status status-<?= strtolower($order['status']) ?>"><?= ucfirst($order['status']) ?></span>
            </div>
            <div class="info-item">
                <label>Placed On</label>
                <span><?= date('d M Y, h:i A', strtotime($order['created_at'])) ?></span>
            </div>
            <div class="info-item">
                <label>Payment Method</label>
                <span><?= strtoupper($order['payment_method'] ?? 'N/A') ?></span>
            </div>
            <div class="info-item">
                <label>Payment Status</label>
                <span><?= ucfirst($order['payment_status'] ?? 'Pending') ?></span>
            </div>
        </div>
    </div>

    <div class="card-box">
        <h3><i class="fas fa-box"></i> Items Ordered</h3>
        <?php foreach ($items ?? [] as $item): ?>
            <?php $imgSrc = str_starts_with($item['product_image'], 'http') ? $item['product_image'] : base_url('images/products/' . $item['product_image']); ?>
            <div class="order-item-row">
                <img src="<?= $imgSrc ?>" alt="<?= esc($item['product_name']) ?>">
                <div class="item-info">
                    <div class="name"><?= esc($item['product_name']) ?></div>
                    <div class="qty">Qty: <?= $item['quantity'] ?> × ₹<?= number_format($item['price']) ?></div>
                </div>
                <div class="item-price">₹<?= number_format($item['subtotal']) ?></div>
            </div>
        <?php endforeach; ?>

        <div style="margin-top:16px; border-top:2px solid #f0f0f0; padding-top:16px;">
            <div class="summary-row"><span>Subtotal</span><span>₹<?= number_format($order['subtotal'] ?? 0) ?></span></div>
            <?php if (($order['discount'] ?? 0) > 0): ?>
                <div class="summary-row" style="color:#27ae60;"><span>Discount</span><span>−₹<?= number_format($order['discount']) ?></span></div>
            <?php endif; ?>
            <div class="summary-row"><span>Tax</span><span>₹<?= number_format($order['tax'] ?? 0) ?></span></div>
            <div class="summary-row"><span>Shipping</span><span><?= ($order['shipping'] ?? 0) > 0 ? '₹' . number_format($order['shipping']) : 'FREE' ?></span></div>
            <div class="summary-row total-row"><span>Total</span><span>₹<?= number_format($order['total'] ?? 0) ?></span></div>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-md-6">
            <div class="card-box">
                <h3><i class="fas fa-map-marker-alt"></i> Shipping Address</h3>
                <p style="font-size:14px; line-height:1.8; color:#555; margin:0;">
                    <strong><?= esc($order['first_name'] . ' ' . $order['last_name']) ?></strong><br>
                    <?= esc($order['address'] ?? '') ?><br>
                    <?= esc($order['city'] ?? '') ?>, <?= esc($order['country'] ?? '') ?> — <?= esc($order['pincode'] ?? '') ?><br>
                    <strong>Phone:</strong> <?= esc($order['phone'] ?? '') ?><br>
                    <strong>Email:</strong> <?= esc($order['email'] ?? '') ?>
                </p>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card-box">
                <h3><i class="fas fa-truck"></i> Order Timeline</h3>
                <div class="timeline">
                    <?php
                    // Fixed to match your database ENUM exactly
                    $steps = ['pending' => 'Order Placed', 'confirmed' => 'Confirmed', 'processing' => 'Processing', 'shipped' => 'Shipped', 'delivered' => 'Delivered'];
                    $statusOrder = array_keys($steps);
                    $currentIdx  = array_search($order['status'], $statusOrder);
                    
                    // If status is cancelled, override timeline
                    if($order['status'] === 'cancelled'): ?>
                        <div class="timeline-step done">
                            <div class="step-label" style="color:#721c24;">Order Cancelled</div>
                            <div class="step-date"><?= date('d M Y', strtotime($order['updated_at'])) ?></div>
                        </div>
                    <?php else:
                        foreach ($steps as $key => $label):
                            $idx  = array_search($key, $statusOrder);
                            $done = $idx <= $currentIdx;
                        ?>
                            <div class="timeline-step <?= $done ? 'done' : '' ?>">
                                <div class="step-label"><?= $label ?></div>
                                <?php if ($done && $idx === $currentIdx): ?>
                                    <div class="step-date"><?= date('d M Y', strtotime($order['updated_at'])) ?></div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; 
                    endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo view('layouts/footer'); ?>