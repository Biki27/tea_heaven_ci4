<?php
$extra_css = '
body { padding-top: 90px; background: #f8f9fa; }
:root { --leaf-green: #6B8E23; --tea-gold: #D4AF37; --warm-brown: #4E342E; }

.orders-wrap { max-width:1000px; margin:0 auto; padding:2rem 1rem; }
.page-title { font-size:1.8rem; font-weight:700; margin-bottom:1.5rem; color:#222; }
.empty-state { text-align:center; padding:80px 20px; background:white; border-radius:16px; box-shadow:0 4px 15px rgba(0,0,0,0.06); }
.empty-state i { font-size:70px; color:#ddd; margin-bottom:16px; display:block; }
.order-card { background:white; border-radius:16px; box-shadow:0 4px 15px rgba(0,0,0,0.06); margin-bottom:1.2rem; overflow:hidden; transition:all 0.3s; }
.order-card:hover { box-shadow:0 10px 30px rgba(0,0,0,0.12); transform:translateY(-2px); }
.order-header { display:flex; align-items:center; justify-content:space-between; padding:1.2rem 1.5rem; border-bottom:1px solid #f0f0f0; flex-wrap:wrap; gap:10px; }
.order-id { font-weight:700; font-size:15px; color:#222; }
.order-date { font-size:13px; color:#999; }
.order-total { font-weight:700; font-size:1.1rem; color:var(--leaf-green); }
.badge-status { padding:4px 14px; border-radius:20px; font-size:12px; font-weight:700; text-transform:uppercase; }
.status-pending    { background:#fff3cd; color:#856404; }
.status-confirmed  { background:#cce5ff; color:#004085; }
.status-processing { background:#cce5ff; color:#004085; }
.status-shipped    { background:#d4edda; color:#155724; }
.status-delivered  { background:#d4edda; color:#155724; }
.status-cancelled  { background:#f8d7da; color:#721c24; }
.order-actions { padding:1.2rem 1.5rem; display:flex; justify-content:space-between; align-items:center; }
.payment-info { font-size:13px; color:#555; }
.payment-info strong { color:#222; }
.btn-details { padding:8px 20px; border-radius:20px; background:var(--leaf-green); color:white; border:none; font-size:13px; font-weight:600; cursor:pointer; text-decoration:none; transition:0.2s; }
.btn-details:hover { background:var(--warm-brown); color:white; }
';
echo view('layouts/header', compact('extra_css') + ['title' => 'My Orders — Tea Haven', 'cartCount' => $cartCount ?? 0]);
?>

<div class="orders-wrap">
    <h1 class="page-title"><i class="fas fa-box me-2" style="color:var(--leaf-green);"></i>My Orders</h1>

    <?php if (!empty($orders)): ?>
        <?php foreach ($orders as $order): ?>
            <div class="order-card">
                <div class="order-header">
                    <div>
                        <div class="order-id">Order #<?= esc($order['order_number']) ?></div>
                        <div class="order-date"><?= date('d M Y, h:i A', strtotime($order['created_at'])) ?></div>
                    </div>
                    <span class="badge-status status-<?= strtolower($order['status']) ?>">
                        <?= ucfirst($order['status']) ?>
                    </span>
                    <div class="order-total">₹<?= number_format($order['total']) ?></div>
                </div>

                <div class="order-actions">
                    <div class="payment-info">
                        Payment: <strong><?= strtoupper($order['payment_method']) ?></strong>
                        <span style="color:#ccc; margin:0 8px;">|</span>
                        Status: <strong class="<?= $order['payment_status'] === 'paid' ? 'text-success' : 'text-warning' ?>"><?= ucfirst($order['payment_status']) ?></strong>
                    </div>
                    <a href="<?= base_url('orders/' . $order['id']) ?>" class="btn-details">
                        <i class="fas fa-eye me-1"></i> View Details
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-box-open"></i>
            <h3>No orders yet</h3>
            <p class="text-muted mb-4">You haven't placed any orders. Start shopping!</p>
            <a href="<?= base_url('products') ?>" class="btn-details" style="padding:12px 30px; font-size:15px;">
                <i class="fas fa-leaf me-2"></i> Browse Teas
            </a>
        </div>
    <?php endif; ?>
</div>

<?php echo view('layouts/footer'); ?>